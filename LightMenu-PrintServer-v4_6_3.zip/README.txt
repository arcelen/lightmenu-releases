LightMenu Print Server v4.6.3
=============================

NEW IN v4.6.3:
  - "Per Section" ticket mode support. On the check ticket, items are
    grouped under "-- DRINKS --" and "-- MENU --" headings when the
    payload carries item.section ('drinks' or 'menu').
  - Kitchen/bar tickets still receive only their routed section's items
    (the app splits them into separate PrintQueue records).

CARRIED OVER FROM v4.6.2:
  - Instagram handle under restaurant address ([IG] @handle)
  - Paid add-ons indented under each main item (kitchen + check)
  - QR code at bottom of bill linking to saved digital bill

INSTALL:
  Right-click install.bat -> Run as Administrator

PAYLOAD FIELDS for a check:
  - restaurant_instagram: URL or @handle (optional)
  - bill_url: URL to saved digital bill (drives QR)
  - items: [{qty, name, price, section?: 'drinks'|'menu', selected_addons?: [...], special_requests?}]
