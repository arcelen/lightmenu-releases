const net   = require('net');
const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

// ─── PRE-CONFIGURED PER RESTAURANT ────────────────────────────────────────────
// The LightMenu app replaces these placeholders when generating the agent zip.
const RESTAURANT_ID = '__RESTAURANT_ID__';
const API_KEY       = '__API_KEY__';
const APP_ID        = '68c97ef1ec28d583a202aa9e';

const SERVER_PORT  = 3000;

// Default printer — overridden by the first active PrinterConfig from LightMenu
let PRINTER_IP   = '192.168.1.200';
let PRINTER_PORT = 9100;

// ─── PRINTER CACHE (refreshed every 30s from LightMenu API) ───────────────────
let printersCache = [];
let printersCacheTime = 0;

function fetchPrintersFromApp() {
  return new Promise((resolve, reject) => {
    if (!RESTAURANT_ID || RESTAURANT_ID === '__RESTAURANT_ID__') return resolve([]);
    if (!API_KEY || API_KEY === '__API_KEY__') return resolve([]);
    const q = encodeURIComponent(JSON.stringify({ restaurant_id: RESTAURANT_ID, is_active: true }));
    const url = 'https://api.base44.com/api/apps/' + APP_ID + '/entities/PrinterConfig?query=' + q + '&limit=20';
    const req = https.request(url, { method: 'GET', headers: { 'apikey': API_KEY } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          const list = data.entities || data;
          resolve(Array.isArray(list) ? list : []);
        } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function refreshPrinters() {
  try {
    const list = await fetchPrintersFromApp();
    if (list.length) {
      printersCache = list;
      printersCacheTime = Date.now();
      const first = list[0];
      if (first.printer_ip) PRINTER_IP = first.printer_ip;
      log('Synced ' + list.length + ' printer(s) from LightMenu (default: ' + PRINTER_IP + ')');
    }
  } catch (e) { log('Printer sync failed: ' + e.message); }
}
setInterval(refreshPrinters, 30000);
setTimeout(refreshPrinters, 1000);


let printed = 0, failed = 0;

function log(m) { console.log('[' + new Date().toLocaleTimeString() + '] ' + m); }

function sendToPrinter(data) {
  return new Promise((resolve, reject) => {
    const s = new net.Socket();
    const t = setTimeout(() => { s.destroy(); reject(new Error('Printer timeout')); }, 8000);
    s.connect(PRINTER_PORT, PRINTER_IP, () => { s.write(data, () => s.end()); });
    s.on('close', () => { clearTimeout(t); resolve(); });
    s.on('error', e => { clearTimeout(t); reject(e); });
  });
}

// ─── ESC/POS ──────────────────────────────────────────────────────────────────
const E = '\x1B', G = '\x1D';
const W = 48;
const FONT_NORMAL  = E + '!' + '\x00';   // S
const FONT_BOLD    = E + '!' + '\x08';
const FONT_TITLE   = E + '!' + '\x10';   // M = double-height
const FONT_LARGE   = E + '!' + '\x30';   // L = double-height + double-width
const FONT_LARGE_B = E + '!' + '\x38';   // L bold
const ALIGN_LEFT   = E + 'a' + '\x00';
const ALIGN_CENTER = E + 'a' + '\x01';
const ALIGN_RIGHT  = E + 'a' + '\x02';
const REVERSE_ON   = G + 'B' + '\x01';   // white-on-black
const REVERSE_OFF  = G + 'B' + '\x00';
const FEED = (n) => E + 'd' + String.fromCharCode(n);
const CUT  = G + 'V' + '\x42' + '\x00';
const INIT = E + '@';

function sepLine(style) {
  if (style === 'dashes') return '-'.repeat(W);
  if (style === 'stars')  return '*'.repeat(W);
  if (style === 'dots')   return '.'.repeat(W);
  return '='.repeat(W); // 'lines' default
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function resolveCurrency(c) {
  const m = {EUR:'EUR',USD:'$',GBP:'GBP',TND:'DT',MAD:'MAD',DZD:'DZD',CHF:'CHF',CAD:'CAD',AUD:'AUD',JPY:'JPY',CNY:'CNY'};
  if (c && c.length <= 3 && !m[c]) return c;
  return m[c] || c || 'EUR';
}
function fmtPrice(amount, currency) {
  const sym = resolveCurrency(currency);
  const val = Number(amount || 0).toFixed(2);
  return (sym.length > 1 ? sym + ' ' : sym) + val;
}
function tr(s, m) { s = String(s || ''); return s.length > m ? s.slice(0, m) : s; }
function center(text, w) { w = w || W; text = tr(text, w); const p = Math.floor((w - text.length) / 2); return ' '.repeat(Math.max(0, p)) + text; }
function fillLine(left, right) { const dots = W - left.length - right.length; if (dots <= 0) return tr(left, W - right.length) + right; return left + '.'.repeat(dots) + right; }
function padLR(l, r) { const sp = W - l.length - r.length; return l + ' '.repeat(sp < 1 ? 1 : sp) + r; }
function fmtDate(d) { const days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat']; return days[d.getDay()]+' '+String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+d.getFullYear(); }
function fmtTime(d) { return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); }

// ─── ZONE STYLING ─────────────────────────────────────────────────────────────
// Resolve a zone's style settings into ESC/POS prefix bytes
// zoneSize: '', 'S', 'M', 'L'  (empty = 'auto'/default)
// zoneBold: '', 'bold', 'normal'
// zoneAlign: '', 'left', 'center', 'right'
// zoneBg: 'transparent' | '#000000' (any non-transparent => reverse print on black bg)
function zonePrefix(s, defaults) {
  defaults = defaults || {};
  const size  = (s.size  && s.size  !== '') ? s.size  : (defaults.size  || '');
  const bold  = (s.bold  && s.bold  !== '') ? s.bold  : (defaults.bold  || '');
  const align = (s.align && s.align !== '') ? s.align : (defaults.align || '');
  const bg    = s.bg || defaults.bg || 'transparent';

  let out = '';
  if (align === 'center') out += ALIGN_CENTER;
  else if (align === 'right') out += ALIGN_RIGHT;
  else out += ALIGN_LEFT;

  if      (size === 'L') out += (bold === 'bold') ? FONT_LARGE_B : FONT_LARGE;
  else if (size === 'M') out += FONT_TITLE + (bold === 'bold' ? FONT_BOLD : '');
  else if (size === 'S') out += FONT_NORMAL + (bold === 'bold' ? FONT_BOLD : '');
  else /* auto */         out += (bold === 'bold') ? FONT_BOLD : FONT_NORMAL;

  // Background: any non-transparent dark bg → reverse print (white-on-black)
  if (bg && bg !== 'transparent' && bg !== '' && bg !== '#ffffff' && bg !== '#fff') {
    // Only enable reverse for clearly dark backgrounds
    const hex = bg.replace('#', '');
    if (hex.length >= 6) {
      const r = parseInt(hex.slice(0,2),16), g = parseInt(hex.slice(2,4),16), bl = parseInt(hex.slice(4,6),16);
      const lum = 0.299*r + 0.587*g + 0.114*bl;
      if (lum < 128) out += REVERSE_ON;
    }
  }
  return out;
}
function zoneSuffix() { return REVERSE_OFF + FONT_NORMAL + ALIGN_LEFT; }

// ─── KITCHEN / ORDER TICKET ───────────────────────────────────────────────────
function buildKitchenTicket(t) {
  const s = t.settings || {};
  const d = new Date(t.time || Date.now());
  const currency = t.currency;
  const sep = sepLine(s.separator_style);
  let b = INIT;

  // HEADER zone (restaurant name)
  if (s.show_restaurant_header !== false && t.restaurant_name) {
    b += zonePrefix({size:s.order_header_font_size, bold:s.order_header_font_bold, align:s.order_header_align, bg:s.order_header_bg}, {size:'M', bold:'bold', align:'center'});
    b += t.restaurant_name.toUpperCase() + '\n';
    b += zoneSuffix();
  }

  b += sep + '\n';

  // INFO zone (mesa + date + waiter + time)
  const infoPrefix = zonePrefix({size:s.order_info_font_size, bold:s.order_info_font_bold, align:s.order_info_font_align, bg:s.order_info_bg});
  b += infoPrefix;
  b += padLR('Mesa: ' + (t.table_number || '?'), fmtDate(d)) + '\n';
  if (s.show_waiter_name !== false && t.waiter_name) {
    b += padLR('Cam: ' + tr(t.waiter_name, 20), fmtTime(d)) + '\n';
  } else {
    b += padLR('', fmtTime(d)) + '\n';
  }
  b += zoneSuffix();
  b += sep + '\n';

  // ITEMS zone
  const itemsBold = (s.order_items_font_bold === 'bold') || s.order_item_bold;
  const itemsSize = s.order_items_font_size || (s.font_size === 'large' ? 'L' : '');
  for (const item of (t.items || [])) {
    const isInv = item.is_invitation;
    const prefix = isInv ? '[INVIT] ' : '';
    const showPrice = s.show_item_price && !isInv;
    const priceStr = showPrice ? fmtPrice(item.qty * item.price, currency) : '';
    const nameLine = tr(prefix + item.qty + 'x ' + item.name, W - (showPrice ? priceStr.length + 1 : 0));

    b += zonePrefix({size:itemsSize, bold:itemsBold ? 'bold' : '', align:s.order_items_font_align, bg:s.order_items_bg});
    if (showPrice) b += fillLine(nameLine, priceStr) + '\n';
    else           b += nameLine + '\n';
    b += zoneSuffix();
    if (item.special_requests) b += FONT_NORMAL + tr('  * ' + item.special_requests, W) + '\n';
  }

  b += sep + '\n';

  // FOOTER zone
  if (s.kitchen_footer_text) {
    b += zonePrefix({size:s.order_footer_font_size, bold:s.order_footer_font_bold, align:s.order_footer_font_align, bg:s.order_footer_bg}, {align:'center'});
    b += tr(s.kitchen_footer_text, W) + '\n';
    b += zoneSuffix();
  }
  b += FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

// ─── CHECK / BILL TICKET ──────────────────────────────────────────────────────
function buildCheckTicket(t) {
  const s = t.settings || {};
  const currency = t.currency;
  const d = new Date(t.time || Date.now());
  const sep = sepLine(s.separator_style);
  const WL = 24;
  function centerL(text) { text = String(text || '').slice(0, WL); const p = Math.floor((WL - text.length) / 2); return ' '.repeat(Math.max(0, p)) + text; }
  let b = INIT;

  // ── HEADER: restaurant name (LARGE BOLD CENTERED)
  b += '\n' + zonePrefix({size:s.check_header_size||s.check_header_font_size, bold:s.check_header_font_bold||(s.check_header_bold?'bold':''), align:s.check_header_align, bg:s.check_header_bg}, {size:'L', bold:'bold', align:'center'});
  b += centerL((t.restaurant_name || 'Restaurant').toUpperCase()) + '\n';
  b += zoneSuffix() + '\n';

  // Address & phone
  if ((s.check_show_address !== false) && t.restaurant_address) {
    b += FONT_BOLD + center(tr(t.restaurant_address, W)) + '\n' + FONT_NORMAL;
  }
  if ((s.check_show_phone !== false) && t.restaurant_phone) {
    b += FONT_BOLD + center('Tel: ' + t.restaurant_phone) + '\n' + FONT_NORMAL;
  }
  b += '\n' + ALIGN_LEFT + sep + '\n\n';

  // ── INFO zone
  b += zonePrefix({size:s.check_info_font_size, bold:s.check_info_font_bold, align:s.check_info_font_align, bg:s.check_info_bg}, {bold:'bold'});
  const LW = 10;
  function infoRow(label, value) { const l = (label + ':').padEnd(LW); return l + tr(String(value), W - LW) + '\n'; }
  b += infoRow('Date',  fmtDate(d));
  b += infoRow('Time',  fmtTime(d));
  b += infoRow('Table', 'Mesa ' + (t.table_number || '?'));
  if ((s.check_show_waiter !== false) && t.waiter_name) b += infoRow('Waiter', t.waiter_name);
  if (t.guest_count && t.guest_count >= 1)              b += infoRow('Covers', t.guest_count + ' persons');
  b += zoneSuffix();
  b += '\n' + sep + '\n\n';

  // ── ORDER DETAILS section header
  b += ALIGN_CENTER + FONT_BOLD + center('- ORDER DETAILS -') + '\n' + FONT_NORMAL + ALIGN_LEFT + '\n';

  // ── ITEMS zone
  const itemsSize = s.check_items_font_size || s.check_item_size || '';
  const itemsBold = s.check_items_font_bold || '';
  let subtotal = 0, itemCount = 0;
  for (const item of (t.items || [])) {
    const qty = item.qty || 1, price = item.price || 0, lineTotal = qty * price;
    b += zonePrefix({size:itemsSize, bold:itemsBold||'bold', align:s.check_items_font_align, bg:s.check_items_bg});
    if (item.is_invitation) {
      b += fillLine(tr(qty + 'x ' + item.name, W - 9), '[GRATIS]') + '\n';
    } else {
      subtotal += lineTotal; itemCount += qty;
      const priceStr = fmtPrice(lineTotal, currency);
      b += fillLine(tr(qty + 'x ' + item.name, W - priceStr.length - 1), priceStr) + '\n';
    }
    b += zoneSuffix();
    if (item.special_requests) b += FONT_BOLD + tr('  >> ' + item.special_requests, W) + '\n' + FONT_NORMAL;
  }

  // Subtotal / VAT
  b += '\n' + '-'.repeat(W) + '\n\n';
  b += FONT_BOLD + fillLine('Items: ' + itemCount, 'Subtotal: ' + fmtPrice(subtotal, currency)) + '\n' + FONT_NORMAL;
  b += FONT_BOLD + center('( VAT included )') + '\n' + FONT_NORMAL + '\n';

  // ── TOTAL zone
  b += sep + '\n\n' + ALIGN_CENTER;
  b += FONT_TITLE + center('TOTAL') + '\n' + FONT_NORMAL;
  const totalStyle = s.check_total_style || (s.check_bold_total ? 'bold' : 'normal');
  if (totalStyle === 'large_bold') b += FONT_LARGE_B;
  else if (totalStyle === 'bold')  b += FONT_LARGE_B;
  else                             b += FONT_LARGE;
  b += centerL(fmtPrice(t.total || subtotal, currency)) + '\n' + FONT_NORMAL;
  b += '\n' + ALIGN_LEFT + sep + '\n';

  // ── SPLIT BILL (side-by-side when guest_count > 2)
  if (t.guest_count && t.guest_count >= 2) {
    const total = t.total || subtotal;
    const half = W / 2;
    b += '\n' + ALIGN_LEFT + '-'.repeat(W) + '\n\n';
    if (t.guest_count > 2) {
      const leftLabel  = 'Split / ' + t.guest_count + ' persons';
      const leftAmount = fmtPrice(total / t.guest_count, currency) + ' /pers';
      const rightLabel  = 'Split / 2 persons';
      const rightAmount = fmtPrice(total / 2, currency) + ' /pers';
      function padHalf(x) { x = String(x).slice(0, half); return x + ' '.repeat(half - x.length); }
      b += FONT_NORMAL + padHalf(leftLabel) + padHalf(rightLabel) + '\n';
      b += FONT_BOLD   + padHalf(leftAmount) + padHalf(rightAmount) + '\n' + FONT_NORMAL;
    } else {
      b += FONT_BOLD + fillLine('Split / 2 persons', fmtPrice(total / 2, currency) + ' per person') + '\n' + FONT_NORMAL;
    }
    b += '\n' + '-'.repeat(W) + '\n\n';
  }

  // Payment method
  if (t.payment_method && t.payment_method !== 'unpaid') {
    const pl = { cash:'** CASH **', card:'** CARD **', mixed:'** CASH + CARD **' }[t.payment_method] || '';
    if (pl) b += '\n' + ALIGN_CENTER + FONT_TITLE + center(pl) + '\n' + FONT_NORMAL + ALIGN_LEFT + '\n';
  }

  // ── FOOTER zone
  b += sep + '\n\n';
  b += zonePrefix({size:s.check_footer_font_size, bold:s.check_footer_font_bold, align:s.check_footer_font_align, bg:s.check_footer_bg}, {bold:'bold', align:'center'});
  const footerText = s.check_footer_text || 'Gracias por su visita!\nThank you for your visit!';
  for (const line of footerText.split(/\\n|\n/)) if (line.trim()) b += center(line.trim()) + '\n';
  b += zoneSuffix();
  b += '\n' + center('- - - - - - - - - - - - -') + '\n\n';
  b += FONT_BOLD + center('Powered by LightMenu') + '\n' + center('lightmenu.app') + '\n' + FONT_NORMAL;
  b += '\n' + ALIGN_LEFT + sep + '\n' + FEED(6) + CUT;
  return Buffer.from(b, 'binary');
}

// ─── CANCELLATION TICKET ──────────────────────────────────────────────────────
function buildCancellationTicket(t) {
  const s = t.settings || {};
  const currency = t.currency;
  const d = new Date(t.time || Date.now());
  const sep = sepLine(s.separator_style);
  let b = INIT;

  // HEADER (CANCELLED banner)
  b += zonePrefix({size:s.cancel_header_font_size||'L', bold:s.cancel_header_font_bold||'bold', align:s.cancel_header_align||'center', bg:s.cancel_header_bg}, {size:'L', bold:'bold', align:'center'});
  b += '!! CANCELLED !!\n';
  b += zoneSuffix();
  b += sep + '\n';

  if (s.cancel_show_restaurant_name !== false && t.restaurant_name) {
    b += FONT_BOLD + center(t.restaurant_name.toUpperCase()) + '\n' + FONT_NORMAL;
  }

  // INFO
  b += zonePrefix({size:s.cancel_info_font_size, bold:s.cancel_info_font_bold, align:s.cancel_info_font_align, bg:s.cancel_info_bg});
  b += padLR('Mesa: ' + (t.table_number || '?'), fmtDate(d) + ' ' + fmtTime(d)) + '\n';
  if (t.waiter_name) b += 'Cam: ' + tr(t.waiter_name, W - 5) + '\n';
  b += zoneSuffix();
  b += sep + '\n';

  // ITEMS
  for (const item of (t.items || [])) {
    const priceStr = fmtPrice((item.qty || 1) * (item.price || 0), currency);
    b += zonePrefix({size:s.cancel_items_font_size, bold:s.cancel_items_font_bold, align:s.cancel_items_font_align, bg:s.cancel_items_bg});
    b += fillLine(tr('X ' + (item.qty || 1) + 'x ' + item.name, W - priceStr.length - 1), priceStr) + '\n';
    b += zoneSuffix();
  }
  b += sep + '\n';

  if (s.cancel_show_cancelled_by !== false && t.cancelled_by) {
    b += ALIGN_CENTER + 'Cancelled by: ' + t.cancelled_by + '\n' + ALIGN_LEFT;
  }

  // FOOTER
  if (s.cancel_footer_text) {
    b += zonePrefix({size:s.cancel_footer_font_size, bold:s.cancel_footer_font_bold, align:s.cancel_footer_font_align, bg:s.cancel_footer_bg}, {align:'center'});
    b += tr(s.cancel_footer_text, W) + '\n';
    b += zoneSuffix();
  }
  b += FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

// ─── TRANSFER TICKET ──────────────────────────────────────────────────────────
function buildTransferTicket(t) {
  const s = t.settings || {};
  const currency = t.currency;
  const d = new Date(t.time || Date.now());
  const sep = sepLine(s.separator_style);
  let b = INIT;

  b += zonePrefix({size:s.transfer_header_font_size||s.transfer_header_size, bold:s.transfer_header_font_bold||(s.transfer_header_bold?'bold':''), align:s.transfer_header_align, bg:s.transfer_header_bg}, {size:'M', bold:'bold', align:'center'});
  b += 'TABLE TRANSFER\n';
  b += zoneSuffix();
  b += sep + '\n';

  if (s.transfer_show_restaurant_name !== false && t.restaurant_name) {
    b += center(t.restaurant_name.toUpperCase()) + '\n';
  }

  const arrow = s.transfer_arrow_style === 'double_arrow' ? '  =>  ' : (s.transfer_arrow_style === 'label' ? '  TO  ' : '  ->  ');
  b += FONT_BOLD + center('Mesa ' + (t.from_table || '?') + arrow + 'Mesa ' + (t.to_table || '?')) + '\n' + FONT_NORMAL;

  b += zonePrefix({size:s.transfer_info_font_size, bold:s.transfer_info_font_bold, align:s.transfer_info_font_align, bg:s.transfer_info_bg});
  b += padLR('', fmtDate(d) + ' ' + fmtTime(d)) + '\n';
  if (t.waiter_name) b += 'Cam: ' + tr(t.waiter_name, W - 5) + '\n';
  b += zoneSuffix();
  b += sep + '\n';

  for (const item of (t.items || [])) {
    const priceStr = fmtPrice((item.qty || 1) * (item.price || 0), currency);
    b += zonePrefix({size:s.transfer_items_font_size||s.transfer_item_size, bold:s.transfer_items_font_bold, align:s.transfer_items_font_align, bg:s.transfer_items_bg});
    b += fillLine(tr((item.qty || 1) + 'x ' + item.name, W - priceStr.length - 1), priceStr) + '\n';
    b += zoneSuffix();
  }
  b += sep + '\n';

  if (s.transfer_footer_text) {
    b += zonePrefix({size:s.transfer_footer_font_size, bold:s.transfer_footer_font_bold, align:s.transfer_footer_font_align, bg:s.transfer_footer_bg}, {align:'center'});
    b += tr(s.transfer_footer_text, W) + '\n';
    b += zoneSuffix();
  }
  b += FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

// ─── HTTP SERVER ──────────────────────────────────────────────────────────────
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept, Origin');
  res.setHeader('Access-Control-Max-Age', '86400');
}

http.createServer((req, res) => {
  setCORS(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  if (req.method === 'GET' && req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'running', version: '4.6', printer: { ip: PRINTER_IP, port: PRINTER_PORT }, printed, failed }));
    return;
  }

  if (req.method === 'POST' && req.url === '/print') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const ticket = JSON.parse(body);
        let data;
        switch (ticket.type) {
          case 'check':    data = buildCheckTicket(ticket);        log('CHECK: Mesa ' + ticket.table_number); break;
          case 'cancel':   data = buildCancellationTicket(ticket); log('CANCEL: Mesa ' + ticket.table_number); break;
          case 'transfer': data = buildTransferTicket(ticket);     log('TRANSFER: Mesa ' + ticket.from_table + ' -> ' + ticket.to_table); break;
          default:         data = buildKitchenTicket(ticket);      log('KITCHEN: Mesa ' + ticket.table_number);
        }
        const copies = (ticket.type === 'check' ? (ticket.settings && ticket.settings.check_copies) : (ticket.settings && ticket.settings.order_copies)) || 1;
        for (let i = 0; i < Math.min(copies, 3); i++) await sendToPrinter(data);
        printed++;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        failed++;
        log('FAILED: ' + e.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  if (req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`<!DOCTYPE html><html><head><style>
body{font-family:sans-serif;background:#0f0f0f;color:#e0e0e0;padding:30px}
h1{color:#a78bfa}.ok{color:#22c55e}
table{border-collapse:collapse;margin-top:10px}td{padding:6px 12px;border-bottom:1px solid #222;font-size:13px}
</style></head><body>
<h1>LightMenu Print Server v4.6</h1>
<table>
<tr><td>Printer</td><td><span class=ok>${PRINTER_IP}:${PRINTER_PORT}</span></td></tr>
<tr><td>Printed</td><td><span class=ok>${printed}</span></td></tr>
<tr><td>Failed</td><td>${failed}</td></tr>
<tr><td>Uptime</td><td>${Math.floor(process.uptime())}s</td></tr>
</table></body></html>`);
    return;
  }

  res.writeHead(404); res.end();
}).listen(SERVER_PORT, '0.0.0.0', () => {
  console.log('  LightMenu Print Server v4.6 | ' + PRINTER_IP + ':' + PRINTER_PORT);
});
