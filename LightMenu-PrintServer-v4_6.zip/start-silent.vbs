Dim objShell
Set objShell = CreateObject("WScript.Shell")
objShell.Run "node """ & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\main.js""", 0, False
Set objShell = Nothing
