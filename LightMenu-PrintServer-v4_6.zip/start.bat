@echo off
title LightMenu Print Server
echo Starting LightMenu Print Server...

REM Start the print server
start "LightMenu Print Server" node "%~dp0main.js"

REM Start Cloudflare tunnel
echo Starting Cloudflare Tunnel...
cloudflared tunnel run --token eyJhIjoiNGZmYjBlMzc1ODk0ODcwODE0NGE0ZGVmODNmNTllMGMiLCJzIjoiN2xDSUJRY3J5dUZMTC9paERsWmJZL3dWM0JEQ2QxdGJERS8vTk5RU3IzQT0iLCJ0IjoiYzI1MTQ3MjctMmQ5OS00ZjEzLTg1YzctZGY3M2E3ZjAwNjI5In0=

pause
