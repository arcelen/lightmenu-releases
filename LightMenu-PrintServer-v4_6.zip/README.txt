LightMenu Print Server v4.0
===========================

FIRST TIME:
  Right-click install.bat -> Run as Administrator

DAILY:
  Starts automatically on Windows boot.
  Or double-click start.bat

PRINTER IP:
  Edit main.js line 4: const PRINTER_IP = '192.168.1.200';
  Change to your printer's IP address.

URL: https://print.lightmenu.app
Tickets: kitchen | check | cancel | transfer
