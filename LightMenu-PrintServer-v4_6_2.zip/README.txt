LightMenu Print Server v4.6.2
=============================

NEW IN v4.6.2:
  - Instagram handle on bill (under address, with [IG] icon)
    Only printed if "restaurant_instagram" is sent in the print payload.
  - Paid add-ons appear as indented sub-lines under each main item
    on the check (with their own price) and on the kitchen ticket.
  - QR code at the bottom of every check, linking to the saved
    digital bill ("bill_url" or "qr_url" field in the print payload).

INSTALL:
  Right-click install.bat -> Run as Administrator
  (Replaces any existing LightMenu Print Server installation)

The agent runs silently in the background and auto-starts on Windows boot.
Manage everything from lightmenu.app -> Printer Setup.

PAYLOAD FIELDS (sent by the LightMenu app for each check):
  - restaurant_instagram: full URL or @handle (optional)
  - bill_url: URL to the saved digital bill (optional, drives QR)
  - items: each item may include selected_addons: [{name, price}, ...]
