const net   = require('net');
const http  = require('http');
const https = require('https');

// ─── PRE-CONFIGURED PER RESTAURANT ────────────────────────────────────────────
const RESTAURANT_ID = '__RESTAURANT_ID__';
const API_KEY       = '__API_KEY__';
const APP_ID        = '68c97ef1ec28d583a202aa9e';
const APP_HOST      = 'lightmenu.app';
const SERVER_PORT   = 3000;
const POLL_INTERVAL = 4000;     // poll queue every 4s
const PRINTER_REFRESH = 30000;  // refresh printer list every 30s

let printers = [];
let printersLoadedAt = 0;
let printed = 0, failed = 0;
let lastPollAt = null;

function log(m) { console.log('[' + new Date().toLocaleTimeString() + '] ' + m); }

// ─── HTTP helpers ─────────────────────────────────────────────────────────────
function httpsRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve(data ? JSON.parse(data) : null); }
          catch (e) { resolve(data); }
        } else {
          reject(new Error('HTTP ' + res.statusCode + ': ' + data.slice(0, 200)));
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

// ─── PRINTER LIST (from PrinterConfig entity) ─────────────────────────────────
async function refreshPrinters() {
  if (!RESTAURANT_ID || RESTAURANT_ID === '__RESTAURANT_ID__') return;
  try {
    const q = encodeURIComponent(JSON.stringify({ restaurant_id: RESTAURANT_ID, is_active: true }));
    const list = await httpsRequest({
      hostname: 'api.base44.com',
      path: '/api/apps/' + APP_ID + '/entities/PrinterConfig?query=' + q + '&limit=20',
      method: 'GET',
      headers: { 'apikey': API_KEY }
    });
    const items = list.entities || list;
    if (Array.isArray(items)) {
      printers = items;
      printersLoadedAt = Date.now();
      log('Synced ' + items.length + ' printer(s)');
    }
  } catch (e) {
    log('Printer sync failed: ' + e.message);
  }
}

function findPrinter(printerId, printerType) {
  if (printerId) {
    const exact = printers.find(p => p.id === printerId);
    if (exact) return exact;
  }
  return printers.find(p => p.printer_type === printerType && p.is_active !== false)
      || printers.find(p => p.is_active !== false)
      || printers[0];
}

// ─── PRINT QUEUE POLLING ─────────────────────────────────────────────────────
async function fetchPendingJobs() {
  // Try the dedicated queue API first (Base44 may have added /printqueue-api)
  try {
    const r = await httpsRequest({
      hostname: APP_HOST,
      path: '/printqueue-api?restaurant_id=' + RESTAURANT_ID,
      method: 'GET',
      headers: { 'apikey': API_KEY, 'Accept': 'application/json' }
    });
    if (Array.isArray(r)) return r;
    if (r && Array.isArray(r.jobs)) return r.jobs;
    if (r && Array.isArray(r.entities)) return r.entities;
  } catch (e) {
    // Fall back to direct entity query
  }
  // Fallback: query PrintQueue directly
  const q = encodeURIComponent(JSON.stringify({ restaurant_id: RESTAURANT_ID, status: 'pending' }));
  const list = await httpsRequest({
    hostname: 'api.base44.com',
    path: '/api/apps/' + APP_ID + '/entities/PrintQueue?query=' + q + '&limit=50&sort=created_date',
    method: 'GET',
    headers: { 'apikey': API_KEY }
  });
  return list.entities || list || [];
}

async function markJobPrinted(jobId, success, error) {
  try {
    await httpsRequest({
      hostname: 'api.base44.com',
      path: '/api/apps/' + APP_ID + '/entities/PrintQueue/' + jobId,
      method: 'PATCH',
      headers: { 'apikey': API_KEY, 'Content-Type': 'application/json' }
    }, JSON.stringify({ status: success ? 'printed' : 'failed' }));
  } catch (e) {
    log('Mark job ' + jobId + ' failed: ' + e.message);
  }
}

// ─── PRINTER I/O ──────────────────────────────────────────────────────────────
function sendToPrinter(printer, data) {
  return new Promise((resolve, reject) => {
    const ip = printer.printer_ip;
    const port = printer.printer_port || 9100;
    if (!ip) return reject(new Error('Printer has no IP set in LightMenu'));
    const s = new net.Socket();
    const t = setTimeout(() => { s.destroy(); reject(new Error('Printer timeout: ' + ip)); }, 8000);
    s.connect(port, ip, () => { s.write(data, () => s.end()); });
    s.on('close', () => { clearTimeout(t); resolve(); });
    s.on('error', e => { clearTimeout(t); reject(e); });
  });
}

// ─── ESC/POS ──────────────────────────────────────────────────────────────────
const E = '\x1B', G = '\x1D', W = 48;
const FONT_NORMAL  = E + '!' + '\x00';
const FONT_BOLD    = E + '!' + '\x08';
const FONT_TITLE   = E + '!' + '\x10';
const FONT_LARGE   = E + '!' + '\x30';
const FONT_LARGE_B = E + '!' + '\x38';
const ALIGN_LEFT   = E + 'a' + '\x00';
const ALIGN_CENTER = E + 'a' + '\x01';
const ALIGN_RIGHT  = E + 'a' + '\x02';
const REVERSE_ON   = G + 'B' + '\x01';
const REVERSE_OFF  = G + 'B' + '\x00';
const FEED = (n) => E + 'd' + String.fromCharCode(n);
const CUT  = G + 'V' + '\x42' + '\x00';
const INIT = E + '@';

function sepLine(style) {
  if (style === 'dashes') return '-'.repeat(W);
  if (style === 'stars')  return '*'.repeat(W);
  if (style === 'dots')   return '.'.repeat(W);
  return '='.repeat(W);
}

function resolveCurrency(c) {
  const m = {EUR:'EUR',USD:'$',GBP:'GBP',TND:'DT',MAD:'MAD',DZD:'DZD',CHF:'CHF',CAD:'CAD',AUD:'AUD',JPY:'JPY',CNY:'CNY'};
  if (c && c.length <= 3 && !m[c]) return c;
  return m[c] || c || 'EUR';
}
function fmtPrice(amount, currency) {
  const sym = resolveCurrency(currency);
  const val = Number(amount || 0).toFixed(2);
  return (sym.length > 1 ? sym + ' ' : sym) + val;
}
function tr(s, m) { s = String(s || ''); return s.length > m ? s.slice(0, m) : s; }
function center(text, w) { w = w || W; text = tr(text, w); const p = Math.floor((w - text.length) / 2); return ' '.repeat(Math.max(0, p)) + text; }
function fillLine(left, right) { const dots = W - left.length - right.length; if (dots <= 0) return tr(left, W - right.length) + right; return left + '.'.repeat(dots) + right; }
function padLR(l, r) { const sp = W - l.length - r.length; return l + ' '.repeat(sp < 1 ? 1 : sp) + r; }
function fmtDate(d) { const days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat']; return days[d.getDay()]+' '+String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+d.getFullYear(); }
function fmtTime(d) { return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); }

function zonePrefix(s, defaults) {
  defaults = defaults || {};
  const size  = (s.size  && s.size  !== '') ? s.size  : (defaults.size  || '');
  const bold  = (s.bold  && s.bold  !== '') ? s.bold  : (defaults.bold  || '');
  const align = (s.align && s.align !== '') ? s.align : (defaults.align || '');
  const bg    = s.bg || defaults.bg || 'transparent';
  let out = '';
  if (align === 'center') out += ALIGN_CENTER;
  else if (align === 'right') out += ALIGN_RIGHT;
  else out += ALIGN_LEFT;
  if      (size === 'L' || size === 'large')  out += (bold === 'bold') ? FONT_LARGE_B : FONT_LARGE;
  else if (size === 'M')                       out += FONT_TITLE + (bold === 'bold' ? FONT_BOLD : '');
  else if (size === 'S' || size === 'small')   out += FONT_NORMAL + (bold === 'bold' ? FONT_BOLD : '');
  else                                          out += (bold === 'bold') ? FONT_BOLD : FONT_NORMAL;
  if (bg && bg !== 'transparent' && bg !== '' && bg !== '#ffffff') {
    const hex = bg.replace('#', '');
    if (hex.length >= 6) {
      const r = parseInt(hex.slice(0,2),16), g = parseInt(hex.slice(2,4),16), bl = parseInt(hex.slice(4,6),16);
      if (0.299*r + 0.587*g + 0.114*bl < 128) out += REVERSE_ON;
    }
  }
  return out;
}
function zoneSuffix() { return REVERSE_OFF + FONT_NORMAL + ALIGN_LEFT; }

// ─── TICKET BUILDERS ─────────────────────────────────────────────────────────
function buildKitchenTicket(t) {
  const s = t.settings || {};
  const d = new Date(t.time || Date.now());
  const sep = sepLine(s.separator_style);
  let b = INIT;
  if (s.show_restaurant_header !== false && t.restaurant_name) {
    b += zonePrefix({size:s.order_header_font_size, bold:s.order_header_font_bold, align:s.order_header_align, bg:s.order_header_bg}, {size:'M', bold:'bold', align:'center'});
    b += t.restaurant_name.toUpperCase() + '\n';
    b += zoneSuffix();
  }
  b += sep + '\n';
  b += zonePrefix({size:s.order_info_font_size, bold:s.order_info_font_bold, align:s.order_info_font_align, bg:s.order_info_bg});
  b += padLR('Mesa: ' + (t.table_number || '?'), fmtDate(d)) + '\n';
  if (s.show_waiter_name !== false && t.waiter_name) b += padLR('Cam: ' + tr(t.waiter_name, 20), fmtTime(d)) + '\n';
  else b += padLR('', fmtTime(d)) + '\n';
  b += zoneSuffix() + sep + '\n';
  const itemsBold = (s.order_items_font_bold === 'bold') || s.order_item_bold;
  const itemsSize = s.order_items_font_size || (s.font_size === 'large' ? 'L' : '');
  for (const item of (t.items || [])) {
    const isInv = item.is_invitation;
    const prefix = isInv ? '[INVIT] ' : '';
    const showPrice = s.show_item_price && !isInv;
    const priceStr = showPrice ? fmtPrice(item.qty * item.price, t.currency) : '';
    const nameLine = tr(prefix + item.qty + 'x ' + item.name, W - (showPrice ? priceStr.length + 1 : 0));
    b += zonePrefix({size:itemsSize, bold:itemsBold ? 'bold' : '', align:s.order_items_font_align, bg:s.order_items_bg});
    b += showPrice ? fillLine(nameLine, priceStr) + '\n' : nameLine + '\n';
    b += zoneSuffix();
    if (item.special_requests) b += FONT_NORMAL + tr('  * ' + item.special_requests, W) + '\n';
  }
  b += sep + '\n';
  if (s.kitchen_footer_text) {
    b += zonePrefix({size:s.order_footer_font_size, bold:s.order_footer_font_bold, align:s.order_footer_font_align, bg:s.order_footer_bg}, {align:'center'});
    b += tr(s.kitchen_footer_text, W) + '\n';
    b += zoneSuffix();
  }
  b += FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

function buildCheckTicket(t) {
  const s = t.settings || {};
  const currency = t.currency;
  const d = new Date(t.time || Date.now());
  const sep = sepLine(s.separator_style);
  const WL = 24;
  function centerL(text) { text = String(text || '').slice(0, WL); const p = Math.floor((WL - text.length) / 2); return ' '.repeat(Math.max(0, p)) + text; }
  let b = INIT + '\n' + zonePrefix({size:s.check_header_size||s.check_header_font_size, bold:s.check_header_font_bold||(s.check_header_bold?'bold':''), align:s.check_header_align, bg:s.check_header_bg}, {size:'L', bold:'bold', align:'center'});
  b += centerL((t.restaurant_name || 'Restaurant').toUpperCase()) + '\n' + zoneSuffix() + '\n';
  if ((s.check_show_address !== false) && t.restaurant_address) b += FONT_BOLD + center(tr(t.restaurant_address, W)) + '\n' + FONT_NORMAL;
  if ((s.check_show_phone !== false) && t.restaurant_phone) b += FONT_BOLD + center('Tel: ' + t.restaurant_phone) + '\n' + FONT_NORMAL;
  b += '\n' + ALIGN_LEFT + sep + '\n\n';
  b += zonePrefix({size:s.check_info_font_size, bold:s.check_info_font_bold, align:s.check_info_font_align, bg:s.check_info_bg}, {bold:'bold'});
  function infoRow(label, value) { return (label + ':').padEnd(10) + tr(String(value), W - 10) + '\n'; }
  b += infoRow('Date',  fmtDate(d));
  b += infoRow('Time',  fmtTime(d));
  b += infoRow('Table', 'Mesa ' + (t.table_number || '?'));
  if ((s.check_show_waiter !== false) && t.waiter_name) b += infoRow('Waiter', t.waiter_name);
  if (t.guest_count && t.guest_count >= 1) b += infoRow('Covers', t.guest_count + ' persons');
  b += zoneSuffix() + '\n' + sep + '\n\n';
  b += ALIGN_CENTER + FONT_BOLD + center('- ORDER DETAILS -') + '\n' + FONT_NORMAL + ALIGN_LEFT + '\n';
  let subtotal = 0, itemCount = 0;
  for (const item of (t.items || [])) {
    const qty = item.qty || 1, price = item.price || 0, lineTotal = qty * price;
    b += zonePrefix({size:s.check_items_font_size||s.check_item_size, bold:s.check_items_font_bold||'bold', align:s.check_items_font_align, bg:s.check_items_bg});
    if (item.is_invitation) b += fillLine(tr(qty + 'x ' + item.name, W - 9), '[GRATIS]') + '\n';
    else { subtotal += lineTotal; itemCount += qty; const ps = fmtPrice(lineTotal, currency); b += fillLine(tr(qty + 'x ' + item.name, W - ps.length - 1), ps) + '\n'; }
    b += zoneSuffix();
    if (item.special_requests) b += FONT_BOLD + tr('  >> ' + item.special_requests, W) + '\n' + FONT_NORMAL;
  }
  b += '\n' + '-'.repeat(W) + '\n\n' + FONT_BOLD + fillLine('Items: ' + itemCount, 'Subtotal: ' + fmtPrice(subtotal, currency)) + '\n' + FONT_NORMAL;
  b += FONT_BOLD + center('( VAT included )') + '\n' + FONT_NORMAL + '\n' + sep + '\n\n' + ALIGN_CENTER;
  b += FONT_TITLE + center('TOTAL') + '\n' + FONT_NORMAL + FONT_LARGE_B + centerL(fmtPrice(t.total || subtotal, currency)) + '\n' + FONT_NORMAL;
  b += '\n' + ALIGN_LEFT + sep + '\n';
  if (t.guest_count && t.guest_count >= 2) {
    const total = t.total || subtotal;
    const half = W / 2;
    b += '\n' + ALIGN_LEFT + '-'.repeat(W) + '\n\n';
    if (t.guest_count > 2) {
      function padHalf(x) { x = String(x).slice(0, half); return x + ' '.repeat(half - x.length); }
      b += FONT_NORMAL + padHalf('Split / ' + t.guest_count + ' persons') + padHalf('Split / 2 persons') + '\n';
      b += FONT_BOLD + padHalf(fmtPrice(total / t.guest_count, currency) + ' /pers') + padHalf(fmtPrice(total / 2, currency) + ' /pers') + '\n' + FONT_NORMAL;
    } else {
      b += FONT_BOLD + fillLine('Split / 2 persons', fmtPrice(total / 2, currency) + ' per person') + '\n' + FONT_NORMAL;
    }
    b += '\n' + '-'.repeat(W) + '\n\n';
  }
  if (t.payment_method && t.payment_method !== 'unpaid') {
    const pl = { cash:'** CASH **', card:'** CARD **', mixed:'** CASH + CARD **' }[t.payment_method] || '';
    if (pl) b += '\n' + ALIGN_CENTER + FONT_TITLE + center(pl) + '\n' + FONT_NORMAL + ALIGN_LEFT + '\n';
  }
  b += sep + '\n\n' + zonePrefix({size:s.check_footer_font_size, bold:s.check_footer_font_bold, align:s.check_footer_font_align, bg:s.check_footer_bg}, {bold:'bold', align:'center'});
  const footerText = s.check_footer_text || 'Gracias por su visita!\nThank you for your visit!';
  for (const line of footerText.split(/\\n|\n/)) if (line.trim()) b += center(line.trim()) + '\n';
  b += zoneSuffix() + '\n' + center('- - - - - - - - - - - - -') + '\n\n';
  b += FONT_BOLD + center('Powered by LightMenu') + '\n' + center('lightmenu.app') + '\n' + FONT_NORMAL;
  b += '\n' + ALIGN_LEFT + sep + '\n' + FEED(6) + CUT;
  return Buffer.from(b, 'binary');
}

function buildCancellationTicket(t) {
  const s = t.settings || {}, d = new Date(t.time || Date.now()), sep = sepLine(s.separator_style);
  let b = INIT + ALIGN_CENTER + FONT_LARGE_B + '!! CANCELLED !!\n' + FONT_NORMAL + ALIGN_LEFT + sep + '\n';
  if (s.cancel_show_restaurant_name !== false && t.restaurant_name) b += FONT_BOLD + center(t.restaurant_name.toUpperCase()) + '\n' + FONT_NORMAL;
  b += padLR('Mesa: ' + (t.table_number || '?'), fmtDate(d) + ' ' + fmtTime(d)) + '\n';
  if (t.waiter_name) b += 'Cam: ' + tr(t.waiter_name, W - 5) + '\n';
  b += sep + '\n';
  for (const item of (t.items || [])) {
    const ps = fmtPrice((item.qty || 1) * (item.price || 0), t.currency);
    b += fillLine(tr('X ' + (item.qty || 1) + 'x ' + item.name, W - ps.length - 1), ps) + '\n';
  }
  b += sep + '\n';
  if (s.cancel_show_cancelled_by !== false && t.cancelled_by) b += ALIGN_CENTER + 'Cancelled by: ' + t.cancelled_by + '\n' + ALIGN_LEFT;
  if (s.cancel_footer_text) b += ALIGN_CENTER + tr(s.cancel_footer_text, W) + '\n' + ALIGN_LEFT;
  b += FONT_NORMAL + FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

function buildTransferTicket(t) {
  const s = t.settings || {}, d = new Date(t.time || Date.now()), sep = sepLine(s.separator_style);
  let b = INIT + ALIGN_CENTER + FONT_TITLE + 'TABLE TRANSFER\n' + FONT_NORMAL + ALIGN_LEFT + sep + '\n';
  if (s.transfer_show_restaurant_name !== false && t.restaurant_name) b += center(t.restaurant_name.toUpperCase()) + '\n';
  const arrow = s.transfer_arrow_style === 'double_arrow' ? '  =>  ' : (s.transfer_arrow_style === 'label' ? '  TO  ' : '  ->  ');
  b += FONT_BOLD + center('Mesa ' + (t.from_table || '?') + arrow + 'Mesa ' + (t.to_table || '?')) + '\n' + FONT_NORMAL;
  b += padLR('', fmtDate(d) + ' ' + fmtTime(d)) + '\n';
  if (t.waiter_name) b += 'Cam: ' + tr(t.waiter_name, W - 5) + '\n';
  b += sep + '\n';
  for (const item of (t.items || [])) {
    const ps = fmtPrice((item.qty || 1) * (item.price || 0), t.currency);
    b += fillLine(tr((item.qty || 1) + 'x ' + item.name, W - ps.length - 1), ps) + '\n';
  }
  b += sep + '\n';
  if (s.transfer_footer_text) b += ALIGN_CENTER + tr(s.transfer_footer_text, W) + '\n' + ALIGN_LEFT;
  b += FONT_NORMAL + FEED(4) + CUT;
  return Buffer.from(b, 'binary');
}

// ─── PROCESS A QUEUE JOB ──────────────────────────────────────────────────────
async function processJob(job) {
  try {
    // Parse fields
    const items = job.items_json ? JSON.parse(job.items_json) : [];
    const settings = job.settings_json ? JSON.parse(job.settings_json) : {};
    const ticket = {
      type: job.ticket_type || (job.printer_type === 'bar' ? 'check' : 'kitchen'),
      restaurant_name: job.restaurant_name,
      restaurant_address: job.restaurant_address,
      restaurant_phone: job.restaurant_phone,
      currency: job.currency || 'EUR',
      table_number: job.table_number,
      waiter_name: job.waiter_name,
      time: job.order_time || job.created_date,
      total: job.total_amount,
      guest_count: job.guest_count,
      payment_method: job.payment_method,
      from_table: job.from_table,
      to_table: job.to_table,
      cancelled_by: job.cancelled_by,
      items: items,
      settings: settings
    };

    let data;
    switch (ticket.type) {
      case 'check':    data = buildCheckTicket(ticket); break;
      case 'cancel':   data = buildCancellationTicket(ticket); break;
      case 'transfer': data = buildTransferTicket(ticket); break;
      default:         data = buildKitchenTicket(ticket);
    }

    // Find target printer
    const printer = findPrinter(job.printer_id, job.printer_type);
    if (!printer) throw new Error('No active printer found for type ' + job.printer_type);

    await sendToPrinter(printer, data);
    await markJobPrinted(job.id, true);
    printed++;
    log('✓ Printed job ' + job.id.slice(-6) + ' → ' + printer.name + ' (' + printer.printer_ip + ')');
  } catch (e) {
    failed++;
    log('✗ Job ' + job.id.slice(-6) + ' failed: ' + e.message);
    await markJobPrinted(job.id, false, e.message);
  }
}

// ─── MAIN POLLING LOOP ───────────────────────────────────────────────────────
let polling = false;
async function pollOnce() {
  if (polling) return;
  polling = true;
  try {
    if (!printers.length || (Date.now() - printersLoadedAt) > PRINTER_REFRESH) {
      await refreshPrinters();
    }
    const jobs = await fetchPendingJobs();
    lastPollAt = new Date().toISOString();
    if (jobs.length) {
      log('Found ' + jobs.length + ' pending job(s)');
      for (const job of jobs) await processJob(job);
    }
  } catch (e) {
    log('Poll error: ' + e.message);
  } finally {
    polling = false;
  }
}

// ─── LOCAL STATUS PAGE ───────────────────────────────────────────────────────
http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'GET' && req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      version: '4.7',
      restaurant_id: RESTAURANT_ID,
      printers: printers.length,
      printed, failed,
      last_poll: lastPollAt
    }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`<!DOCTYPE html><html><head><meta charset="utf-8"><style>
body{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e5e5e5;padding:30px;max-width:600px;margin:0 auto}
h1{color:#a78bfa;font-size:18px}.ok{color:#22c55e}
table{width:100%;border-collapse:collapse;margin-top:14px}
td{padding:10px 12px;border-bottom:1px solid #222;font-size:13px}
td:first-child{color:#666;width:140px}
.banner{background:#0d3d2a;border:1px solid #1a6b4a;padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:13px;color:#4ade80}
</style></head><body>
<h1>🖨️ LightMenu Print Agent v4.7</h1>
<div class="banner">✅ Running — polling LightMenu every ${POLL_INTERVAL/1000}s</div>
<table>
<tr><td>Restaurant</td><td>${RESTAURANT_ID.slice(-8)}</td></tr>
<tr><td>Printers loaded</td><td class="ok">${printers.length}</td></tr>
<tr><td>Printed</td><td class="ok">${printed}</td></tr>
<tr><td>Failed</td><td>${failed}</td></tr>
<tr><td>Last poll</td><td>${lastPollAt || 'pending...'}</td></tr>
<tr><td>Uptime</td><td>${Math.floor(process.uptime())}s</td></tr>
</table>
<p style="margin-top:20px;color:#666;font-size:12px">Manage printers and settings at <strong style="color:#a78bfa">lightmenu.app</strong> → Printer Setup</p>
</body></html>`);
}).listen(SERVER_PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ╔════════════════════════════════════════╗');
  console.log('  ║  LightMenu Print Agent v4.7            ║');
  console.log('  ║  Polling every ' + (POLL_INTERVAL/1000) + 's for new jobs        ║');
  console.log('  ╚════════════════════════════════════════╝');
  console.log('');
  if (RESTAURANT_ID === '__RESTAURANT_ID__') {
    console.log('  ⚠️  NOT CONFIGURED — placeholder values present');
    console.log('  Download a fresh installer from lightmenu.app');
    return;
  }
  refreshPrinters();
  setInterval(pollOnce, POLL_INTERVAL);
  setInterval(refreshPrinters, PRINTER_REFRESH);
  setTimeout(pollOnce, 1000);
});
